package com.example.asus.habersitesi2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.Toast;

public class kontrol extends Activity{

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kontrol);

        Toast.makeText(this, getIntent().getExtras().getString("veri"), Toast.LENGTH_SHORT).show();

    }
}
