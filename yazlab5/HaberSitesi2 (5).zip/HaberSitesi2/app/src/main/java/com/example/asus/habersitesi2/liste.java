package com.example.asus.habersitesi2;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Movie;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.ProgressDialog;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import static com.android.volley.VolleyLog.*;

public class liste extends Activity {
    private static final String TAG = MainActivity.class.getSimpleName();
    ListView listView;
    ImageView imageView;
    ListView listView2;
     ArrayList<String>tut=new ArrayList<>();


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.haberlistesi);

      //  Toast.makeText(this, "Selected Radio Button: " + getIntent().getExtras().getString("veri"),Toast.LENGTH_SHORT).show();
        listView = (ListView) findViewById(R.id.listView);
        listView2 = (ListView) findViewById(R.id.listView2);

        getJSON("http://10.40.35.88/getdata.php");
        String url = "http://10.40.35.88/getdata.php";

        final ArrayList<String>list=new ArrayList<>();
        StringRequest stringRequest=new StringRequest(Request.Method.GET,url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    JSONArray array=jsonObject.getJSONArray("haber");
                    String kontrol=getIntent().getExtras().getString("veri");
         if(kontrol.equals("Eğitim")){kontrol="Egitim";} if(kontrol.equals("Gündem")){kontrol="Gundem";}if(kontrol.equals("Tüm Haberler")){kontrol="Tum";}

                    for(int i=0; i<array.length(); i++){
                        JSONObject o=array.getJSONObject(i);
                        String HaberID = o.getString("HaberID");
                        String Tur = o.getString("Tur");
                        if(kontrol.equalsIgnoreCase(Tur)){
                            list.add(HaberID);}
                        else if (kontrol.equalsIgnoreCase("Tum")){
                            list.add(HaberID);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
             //   listView2.setAdapter(arrayAdapter);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, list);
        listView2.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long l) {

                    String pos=Integer.toString(position);
                    Intent my=new Intent(liste.this,liked.class);
                    my.putExtra("veri", list.get(position));//açtığımız sayfaya değer gönderme
                    startActivityForResult(my,0);
            }
        });

    }

    private void getJSON(final String urlWebService) {

        class GetJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
          //      Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                // loadIntoListView(s);
                jsonParse(s);
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        GetJSON getJSON = new GetJSON();
        getJSON.execute();
    }

    private void jsonParse(final String value){

        //  String url = "http://192.168.56.1/dene/details.php";
        String url = "http://10.40.35.88/getdata.php";
        listView = (ListView) findViewById(R.id.listView);


       final ArrayList<String>heroes=new ArrayList<>();
        StringRequest stringRequest=new StringRequest(Request.Method.GET,url,new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray array=jsonObject.getJSONArray("haber");
                            String kontrol=getIntent().getExtras().getString("veri");
    if(kontrol.equals("Eğitim")){kontrol="Egitim";}
    if(kontrol.equals("Gündem")){kontrol="Gundem";}
    if(kontrol.equals("Tüm Haberler")){kontrol="Tum";}
                            for(int i=0; i<array.length(); i++){
                                JSONObject o=array.getJSONObject(i);

                                String RYol = o.getString("RYol");
                                String Baslik = o.getString("Baslik");
                                String Icerik = o.getString("Icerik");
                                String Tur = o.getString("Tur");
                                String HaberID = o.getString("HaberID");
                                String Ytarih = o.getString("Ytarih");
                                //Picasso.with(liste.this).load(RYol).into(imageView);
                                 if(kontrol.equalsIgnoreCase(Tur)){
                                heroes.add(" \n"+Baslik+" \n"+Icerik+" \n"+Tur+" \n"+HaberID+" \n"+Ytarih);}
                                else if (kontrol.equalsIgnoreCase("Tum")){
                                     heroes.add(" \n"+Baslik+" \n"+Icerik+" \n"+Tur+" \n"+HaberID+" \n"+Ytarih);
                                 }

                                //listItems.add(item);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, heroes);
                        listView.setAdapter(arrayAdapter);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }































    private void loadIntoListView(String json) throws JSONException {
      /*  String url;

        listView = (ListView) findViewById(R.id.listView);
        imageView=(ImageView)findViewById(R.id.imageView);
        JSONArray jsonArray = new JSONArray(json);
        String[] heroes = new String[jsonArray.length()];
        String kontrol=getIntent().getExtras().getString("veri");
        for (int i = 0; i < jsonArray.length(); i++) {

            JSONObject obj = jsonArray.getJSONObject(i);
            url = obj.getString("RYol");
            //  String name = obj.getString("Tur");
              String date = obj.getString("Tur");
              String a=date;
            Toast.makeText(this, " " +date+"  "+kontrol,
                    Toast.LENGTH_SHORT).show();
             if(kontrol.equalsIgnoreCase(a))
             {
            heroes[i] =" \n"+obj.getString("Baslik")+" \n"+obj.getString("Icerik")+
                    " \n"+obj.getString("Tur")+" \n"+obj.getString("HaberID")+" \n"+obj.getString("Ytarih");
             }

          url = obj.getString("RYol");
           Picasso.with(this).load(url).into(imageView);
            Toast.makeText(this, " " +url,
                    Toast.LENGTH_SHORT).show();
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, heroes);
        listView.setAdapter(arrayAdapter);*/
    }





}

