package com.example.asus.habersitesi2;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class liste extends Activity {

    ListView listView;
    HaberAdapter adapter;
    String ip= "192.168.1.104/";
    //String ip= "10.40.40.122/";

    final ArrayList<Haber> haberler = new ArrayList<Haber>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.haberlistesi);

        Toast.makeText(this, "Haber Türü:" + getIntent().getExtras().getString("veri"), Toast.LENGTH_SHORT).show();

        listView = findViewById(R.id.listView);

        final ArrayList<String>list=new ArrayList<>();


        getJSON( "http://" + ip + "/getdata.php" );

        String url = "http://" + ip + "getdata.php";

        StringRequest stringRequest = new StringRequest( Request.Method.GET , url , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject( response );
                    JSONArray array = jsonObject.getJSONArray( "haber" );

                    String kontrol = getIntent().getExtras().getString("veri");

                    if (kontrol.equals( "Eğitim" )) {
                        kontrol = "Egitim";
                    }
                    if (kontrol.equals( "Gündem" )) {
                        kontrol = "Gundem";
                    }
                    if (kontrol.equals( "Tüm Haberler" )) {
                        kontrol = "Tum";
                    }

                    for (int i = 0; i < array.length(); i++) {
                        JSONObject o = array.getJSONObject( i );
                        String HaberID = o.getString( "HaberID" );
                        String Tur = o.getString( "Tur" );

                        if (kontrol.equalsIgnoreCase( Tur )) {
                            list.add( HaberID );
                        } else if (kontrol.equalsIgnoreCase( "Tum" )) {
                            list.add( HaberID );
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        } ,
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }
        );
        RequestQueue requestQueue = Volley.newRequestQueue( liste.this );
        requestQueue.add( stringRequest );



        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long l) {
                String veri=list.get(position);

                Intent my=new Intent(liste.this,liked.class);
                my.putExtra("veri", veri);//açtığımız sayfaya haber id yi gönderme
                startActivityForResult(my,0);

            }
        });

    }

    private void getJSON(final String urlWebService) {

        class GetJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                jsonParse(s);
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        GetJSON getJSON = new GetJSON();
        getJSON.execute();
    }

    private void jsonParse(final String value){
        String url = "http://"+ip+"/getdata.php";
        listView = findViewById(R.id.listView);

        final ArrayList<String>heroes=new ArrayList<>();
        StringRequest stringRequest=new StringRequest(Request.Method.GET,url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    JSONArray array=jsonObject.getJSONArray("haber");

                    String kontrol=getIntent().getExtras().getString("veri");

                    if(kontrol.equals("Eğitim")){kontrol="Egitim";}
                    if(kontrol.equals("Gündem")){kontrol="Gundem";}
                    if(kontrol.equals("Tüm Haberler")){kontrol="Tum";}

                    for(int i=0; i<array.length(); i++){
                        JSONObject o=array.getJSONObject(i);

                        String RYol = o.getString("RYol");
                        String Baslik = o.getString("Baslik");
                        String Icerik = o.getString("Icerik");
                        String Tur = o.getString("Tur");
                        String HaberID = o.getString("HaberID");
                        String Ytarih = o.getString("YTarih");

                        if(kontrol.equalsIgnoreCase(Tur)){
                            //heroes.add(" \n"+Baslik+" \n"+Icerik+" \n"+Tur+" \n"+HaberID+" \n"+Ytarih);
                            haberler.add(new Haber(RYol,HaberID,Baslik));
                        }
                        else if (kontrol.equalsIgnoreCase("Tum")){
                            //heroes.add(" \n"+Baslik+" \n"+Icerik+" \n"+Tur+" \n"+HaberID+" \n"+Ytarih);
                            haberler.add(new Haber(RYol,HaberID,Baslik));
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                adapter = new HaberAdapter(liste.this, haberler);
                listView.setAdapter(adapter);

                //ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, heroes);
                //listView.setAdapter(arrayAdapter);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


}

