package com.example.asus.habersitesi2;
import android.app.Activity;
import android.app.VoiceInteractor;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpResponse;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
/*
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;*/
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpRetryException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.android.volley.VolleyLog.*;

public class liked extends AppCompatActivity  {

    String id=null;
    String like=null;
    String dislike=null;
    String views=null;
    int likeCount=0;
    int dislikeCount=0;
    int previewCount=0;
    String baslik=null;
    String tur=null;
    String icerik=null;
    String tarih=null;
    String ryol=null;

    String ip= "192.168.1.104/";

    String url = "http://"+ip+"like.php";
    String likeurl = "http://"+ip+"liked.php";
    String dislikeurl = "http://"+ip+"disliked.php";
    String viewsurl = "http://"+ip+"views.php";

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.like);
        Button liked = (Button)findViewById(R.id.likebutton);
        Button disliked = (Button)findViewById(R.id.dislikebutton);
        final TextView tx=(TextView)findViewById(R.id.textView6);  //goruntu
        final TextView tx1=(TextView)findViewById(R.id.textView2);
        final TextView tx2=(TextView)findViewById(R.id.textView4);
        tx.setText(String.valueOf(0));

        //    Toast.makeText(this, getIntent().getExtras().getString("veri"), Toast.LENGTH_SHORT).show();


        final TextView txbaslik=(TextView)findViewById(com.example.asus.habersitesi2.R.id.textBaslik);
        final TextView txicerik=(TextView)findViewById(com.example.asus.habersitesi2.R.id.textIcerik);
        final TextView txtur=(TextView)findViewById(com.example.asus.habersitesi2.R.id.textTur);
        final TextView txtarih=(TextView)findViewById(com.example.asus.habersitesi2.R.id.textTarih);
        final ImageView image=(ImageView)findViewById(com.example.asus.habersitesi2.R.id.haberImage);

        String detayurl="http://"+ip+"getdata.php";
        StringRequest stringRequest2=new StringRequest(Request.Method.GET,detayurl,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    JSONArray array=jsonObject.getJSONArray("haber");

                    for(int i=0; i<array.length(); i++){
                        //Looper.prepare();
                        JSONObject o=array.getJSONObject(i);
                        String HaberID = o.getString("HaberID");

                        id = o.getString("HaberID");
                        baslik = o.getString("Baslik");
                        tur = o.getString("Tur");
                        tarih = o.getString("YTarih");
                        icerik = o.getString("Icerik");
                        ryol = o.getString("RYol");

                        if(id.equalsIgnoreCase(getIntent().getExtras().getString("veri"))){

                            String RYol = ryol;
                            String YTarih = tarih;
                            String Baslik = baslik;
                            String Icerik = icerik;
                            String Tur = tur;

                            Picasso.with(liked.this)
                                    .load(RYol)
                                    .error(com.example.asus.habersitesi2.R.mipmap.ic_launcher)
                                    .into(image, new com.squareup.picasso.Callback() {
                                        @Override
                                        public void onSuccess() {
                                            Toast.makeText(liked.this, "basarili",Toast.LENGTH_SHORT).show();
                                        }

                                        @Override
                                        public void onError() {
                                            Toast.makeText(liked.this, "basarisiz",Toast.LENGTH_SHORT).show();
                                        }
                                    });

                            txbaslik.setText(Baslik);
                            txtarih.setText(YTarih);
                            txicerik.setText(Icerik);
                            txtur.setText(Tur);
                            break;
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest2);

        StringRequest stringRequest=new StringRequest(Request.Method.GET,url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject=new JSONObject(response);
                    JSONArray array=jsonObject.getJSONArray("haberbilgi");
                    for(int i=0; i<array.length(); i++){
                        JSONObject o=array.getJSONObject(i);
                        id = o.getString("HaberID");
                        like = o.getString("Begenme");
                        dislike = o.getString("Dislike");
                        views = o.getString("Preview");

                        if(id.equalsIgnoreCase(getIntent().getExtras().getString("veri"))){
                            int oq1=Integer.parseInt(views);
                            tx.setText(String.valueOf(oq1));
                            int oq=Integer.parseInt(like);
                            tx1.setText(String.valueOf(oq));
                            int oq2=Integer.parseInt(dislike);
                            tx2.setText(String.valueOf(oq2));

                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }
        );
    //    RequestQueue requestQueue1= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        String a1=tx.getText().toString();
        int aa1=Integer.parseInt(a1);aa1++;
        previewCount=aa1;
        tx.setText(String.valueOf(previewCount));

        StringRequest str=new StringRequest(Request.Method.POST, viewsurl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        //  Toast.makeText(liked.this, " "+response+"  "+like, Toast.LENGTH_SHORT).show();
                        Log.i("My success",""+response);

                    }
                }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(liked.this, "my error :"+error, Toast.LENGTH_LONG).show();
                Log.i("My error",""+error);
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> map = new HashMap<String, String>();
                map.put("views", tx.getText().toString());
                map.put("id",getIntent().getExtras().getString("veri"));
                return map;
            }};
        requestQueue.add(str);

        liked.setOnClickListener(new OnClickListener() { /*************************************************************************/

        @Override
        public void onClick(View view) {
            String a=tx1.getText().toString();
            int aa=Integer.parseInt(a);aa++;
            likeCount=aa;

            tx1.setText(String.valueOf(aa));
            StringRequest stringRequest=new StringRequest(Request.Method.GET,url,new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject=new JSONObject(response);
                        JSONArray array=jsonObject.getJSONArray("haberbilgi");
                        for(int i=0; i<array.length(); i++){
                            JSONObject o=array.getJSONObject(i);
                            id = o.getString("HaberID");
                            like = o.getString("Begenme");
                            dislike = o.getString("Dislike");
                            views = o.getString("Preview");
                            if(id.equalsIgnoreCase(getIntent().getExtras().getString("veri"))){
                                // likeCount = Integer.parseInt(like);
                                //   likeCount++;
                                //  like=Integer.toString(likeCount);
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                        }
                    }
            );

            RequestQueue requestQueue= Volley.newRequestQueue(liked.this);
            requestQueue.add(stringRequest);

            StringRequest str=new StringRequest(Request.Method.POST, likeurl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            //  Toast.makeText(liked.this, " "+response+"  "+like, Toast.LENGTH_SHORT).show();
                            Log.i("My success",""+response);

                        }
                    }, new Response.ErrorListener(){
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(liked.this, "my error :"+error, Toast.LENGTH_LONG).show();
                    Log.i("My error",""+error);
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String> map = new HashMap<String, String>();
                    map.put("like", String.valueOf(likeCount));
                    map.put("id",getIntent().getExtras().getString("veri"));

                    return map;
                }};
            requestQueue.add(str);
        }
        });

        disliked.setOnClickListener(new View.OnClickListener() { /*****************************************************************/

        @Override
        public void onClick(View view) {
            String a=tx2.getText().toString();
            int aa=Integer.parseInt(a);aa++;
            dislikeCount=aa;

            tx2.setText(String.valueOf(aa));
            StringRequest stringRequest=new StringRequest(Request.Method.GET,url,new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject=new JSONObject(response);
                        JSONArray array=jsonObject.getJSONArray("haberbilgi");
                        for(int i=0; i<array.length(); i++){
                            JSONObject o=array.getJSONObject(i);
                            id = o.getString("HaberID");
                            like = o.getString("Begenme");
                            dislike = o.getString("Dislike");
                            views = o.getString("Preview");
                            if(id.equalsIgnoreCase(getIntent().getExtras().getString("veri"))){
                                dislikeCount = Integer.parseInt(dislike);
                                dislikeCount++;
                                dislike=Integer.toString(dislikeCount);
                                /*    Intent my=new Intent(liked.this,kontrol.class);
                                    my.putExtra("veri", dislike);//açtığımız sayfaya değer gönderme
                                    startActivityForResult(my,0);*/
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                        }
                    }
            );

            RequestQueue requestQueue= Volley.newRequestQueue(liked.this);
            requestQueue.add(stringRequest);
            StringRequest str=new StringRequest(Request.Method.POST, dislikeurl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //  Toast.makeText(liked.this, " "+response+"  "+like, Toast.LENGTH_SHORT).show();
                            Log.i("My success",""+response);
                        }
                    }, new Response.ErrorListener(){
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(liked.this, "my error :"+error, Toast.LENGTH_LONG).show();
                    Log.i("My error",""+error);
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {

                    Map<String,String> map = new HashMap<String, String>();
                    map.put("dislike", String.valueOf(String.valueOf(dislikeCount)));
                    map.put("id",getIntent().getExtras().getString("veri"));

                    return map;
                }};
            requestQueue.add(str);
        }
        });
    }


}

