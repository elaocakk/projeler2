package com.example.asus.habersitesi2;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    String tür=null;

    private String[] türler = { "Gündem" , "Spor" , "Eğitim" , "Ekonomi","Tüm Haberler" };
    private Spinner spinnerTürler;
    private ArrayAdapter<String> dataAdapterForTürler;
    Button getirButonu;
    String habertürü = "Tüm Haberler";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.giris);

        getirButonu=findViewById( R.id.button);

        spinnerTürler = (Spinner) findViewById(R.id.spinner);
        dataAdapterForTürler = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, türler);
        dataAdapterForTürler.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTürler.setAdapter(dataAdapterForTürler);

        spinnerTürler.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (parent.getSelectedItem().toString().equals( türler[0] )) {
                    habertürü = "Gündem";
                } else if (parent.getSelectedItem().toString().equals( türler[1] )) {
                    habertürü = "Spor";
                } else if (parent.getSelectedItem().toString().equals( türler[2] )) {
                    habertürü = "Eğitim";
                } else if (parent.getSelectedItem().toString().equals( türler[3] )) {
                    habertürü = "Ekonomi";
                } else if (parent.getSelectedItem().toString().equals( türler[4] )) {
                    habertürü = "Tüm Haberler";
                }
                //Toast.makeText(MainActivity.this, "Haber Türü:" + habertürü, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                habertürü = "Tüm Haberler";
            }
        });


        getirButonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String veri=habertürü;
                Intent my=new Intent(MainActivity.this,liste.class);
                my.putExtra("veri", veri);//açtığımız sayfaya haber id yi gönderme
                startActivityForResult(my,0);
            }

        });


    }

}