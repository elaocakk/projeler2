package com.example.asus.habersitesi2;

public class Haber {
    private String RYol;
    private String  HaberID;
    private  String Baslik;

    public Haber(String r,String h, String b) {
        super();
        this.RYol=r;
        this.HaberID = h;
        this.Baslik = b;
    }

    public String getRYol() { return RYol; }

    public void setRYol(String RYol) { this.RYol = RYol; }

    public String getHaberID() {
        return HaberID;
    }

    public void setHaberID(String haberID) {
        HaberID = haberID;
    }

    public String getBaslik() {
        return Baslik;
    }

    public void setBaslik(String baslik) {
        Baslik = baslik;
    }


}
