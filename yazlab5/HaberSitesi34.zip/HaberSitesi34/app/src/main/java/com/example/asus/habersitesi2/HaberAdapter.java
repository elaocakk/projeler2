package com.example.asus.habersitesi2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class HaberAdapter extends ArrayAdapter<Haber>  {

    private final LayoutInflater inflater;
    private final Context context;
    private ViewHolder holder;
    private final ArrayList<Haber> haberler;

    public HaberAdapter(Context context  , ArrayList<Haber> h) {
        super(context,0, h);
        this.context = context;
        this.haberler = h;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return haberler.size();
    }

    @Override
    public Haber getItem(int position) {
        return haberler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return haberler.get(position).hashCode();
    }

    @Override
    public View getView(int position , View convertView , ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.satir, null);

            holder = new ViewHolder();
            holder.haberImage = (ImageView) convertView.findViewById(R.id.imageHaber);
            holder.haberBaslik = (TextView) convertView.findViewById(R.id.haberBaslik);
            holder.haberRYol=(TextView) convertView.findViewById(R.id.haberRYol);
            convertView.setTag(holder);

        }
        else{
            holder = (ViewHolder)convertView.getTag();
        }

        Haber haber = haberler.get(position);
        if(haber != null){
            holder.haberBaslik.setText(haber.getBaslik());
            holder.haberRYol.setText(haber.getHaberID());

            String url=haber.getRYol();

            Picasso.with(context)
                    .load(url)
                    .error( R.mipmap.ic_launcher)
                    .into(holder.haberImage, new Callback() {
                        @Override
                        public void onSuccess() {
                           //Toast.makeText( HaberAdapter.this,"basarili",Toast.LENGTH_SHORT ).show();
                        }

                        @Override
                        public void onError() {
                            //Toast.makeText(HaberAdapter.this, "basarisiz",Toast.LENGTH_SHORT).show();
                        }
                    });
        }


        return convertView;

    }

    private static class ViewHolder {
        TextView haberBaslik;
        ImageView haberImage;
        TextView haberRYol;
    }


    }



