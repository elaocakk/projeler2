﻿namespace FirebaseConnect
{
    internal class Firma
    {
        public string id { get; set; }
        public string ad { get; set; }
        public string lokasyon { get; set; }
        public string icerik { get; set; }
        public string sure { get; set; }
        public string tur { get; set; }
    }
}