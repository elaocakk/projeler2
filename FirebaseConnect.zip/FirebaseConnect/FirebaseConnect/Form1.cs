﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;


namespace FirebaseConnect
{
    public partial class Form1 : Form
    {
        public IFirebaseConfig config { get; set; } = new FirebaseConfig
        {
            AuthSecret = "vu4nhL8TMc8XMqgwAW1t4boaauQ4uJLeVCecBHO3",
            BasePath = "https://uygulama-68dca.firebaseio.com/"
        };

        IFirebaseClient client;
     

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            client = new FireSharp.FirebaseClient(config);

            if(client!=null)
            {
                MessageBox.Show("connection is successfull ");
            }

        }

        private async void button1_Click(object sender, EventArgs e)
        {
           
                var firma = new Firma
                {
                    id = textBox1.Text,
                    ad = textBox2.Text,
                    lokasyon = textBox3.Text,
                    icerik = textBox4.Text,
                    sure = textBox5.Text,
                    tur = textBox6.Text
                };

                string url = " https://us-central1-uygulama-68dca.cloudfunctions.net/addItem?" +
                    "ad=" + firma.ad +
                    "&id=" + firma.id +
                    "&lokasyon=" + firma.lokasyon +
                    "&icerik=" + firma.icerik +
                    "&sure=" + firma.sure +
                    "&tur=" + firma.tur;

                var prs = new ProcessStartInfo("chrome.exe");
                prs.Arguments = url;
                Process.Start(prs);



        }
    }
}
