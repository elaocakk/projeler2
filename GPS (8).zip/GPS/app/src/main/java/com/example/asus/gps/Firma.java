package com.example.asus.gps;


public class Firma {
    String FirmaAdi;
    String FirmaID;
    String FirmaLokasyon;
    String KampanyaIcerik;
    String KampanyaSuresi;
    String Tur;

    public Firma(String firmaAdi, String firmaID, String firmaLokasyon, String kampanyaIcerik, String kampanyaSuresi, String tur) {
        FirmaAdi = firmaAdi;
        FirmaID = firmaID;
        FirmaLokasyon = firmaLokasyon;
        KampanyaIcerik = kampanyaIcerik;
        KampanyaSuresi = kampanyaSuresi;
        Tur = tur;
    }

    public Firma() {
    }

    public String getFirmaAdi() {
        return FirmaAdi;
    }

    public void setFirmaAdi(String firmaAdi) {
        FirmaAdi = firmaAdi;
    }

    public String getFirmaID() {
        return FirmaID;
    }

    public void setFirmaID(String firmaID) {
        FirmaID = firmaID;
    }

    public String getFirmaLokasyon() {
        return FirmaLokasyon;
    }

    public void setFirmaLokasyon(String firmaLokasyon) {
        FirmaLokasyon = firmaLokasyon;
    }

    public String getKampanyaIcerik() {
        return KampanyaIcerik;
    }

    public void setKampanyaIcerik(String kampanyaIcerik) {
        KampanyaIcerik = kampanyaIcerik;
    }

    public String getKampanyaSuresi() {
        return KampanyaSuresi;
    }

    public void setKampanyaSuresi(String kampanyaSuresi) {
        KampanyaSuresi = kampanyaSuresi;
    }

    public String getTur() {
        return Tur;
    }

    public void setTur(String tur) {
        Tur = tur;
    }
}
