package com.example.asus.gps;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePassword extends AppCompatActivity implements View.OnClickListener {

    Button degis;
    EditText eski;
    EditText yeni;
    FirebaseAuth fAuth;
    private ProgressDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.changepassword);
        fAuth=FirebaseAuth.getInstance();
        degis=(Button)findViewById(R.id.button);
        eski=(EditText)findViewById(R.id.eski);
        yeni=(EditText)findViewById(R.id.yeni);
        dialog = new ProgressDialog(this);
        degis.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
if (view==degis){
    change(view);
}
    }
    public void change (View view){
        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        if(user!=null){

            dialog.setMessage("Şifreniz Değiştiriliyor..");
            dialog.show();
            user.updatePassword(yeni.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()){
                        dialog.dismiss();
                        Toast.makeText(getApplicationContext(),"Şifreniz Değişti!",Toast.LENGTH_LONG).show();
                        finish();
                        startActivity(new Intent(ChangePassword.this,Profile.class));
                    }
                    else {
                        dialog.dismiss();
                        Toast.makeText(getApplicationContext(),"Şifreniz Değişmedi!",Toast.LENGTH_LONG).show();

                    }
                }
            });
        }
    }
}
