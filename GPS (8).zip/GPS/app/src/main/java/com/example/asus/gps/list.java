package com.example.asus.gps;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.android.volley.Response;
import java.util.ArrayList;


public class list extends AppCompatActivity {

    ListView listView;
    private String lat1;
    private String lng1;
    private String mesafe;
    String uzak="0 0";
    private String[] separated;
    private ArrayList<String>heroes=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list);

        listView = findViewById(R.id.listView);
        final ArrayList<String>list=new ArrayList<>();
        getJSON( "https://us-central1-savvy-raceway-239511.cloudfunctions.net/getItems" );
        String url = "https://us-central1-savvy-raceway-239511.cloudfunctions.net/getItems";

        StringRequest stringRequest=new StringRequest(Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            String kategori = getIntent().getExtras().getString("kategori");
                            String magaza = getIntent().getExtras().getString("magaza");
                            lat1 = getIntent().getExtras().getString("lat1");
                            lng1 = getIntent().getExtras().getString("lng1");
                            mesafe = getIntent().getExtras().getString("mesafe");

                            JSONArray array = new JSONArray(response);
                            for (int i = 0; i < array.length(); i++) {
                                JSONObject o = array.getJSONObject(i);

                                String id = o.getString("id");
                                String firmaAdi = o.getString("FirmaAdi");
                                String firmaID = o.getString("FirmaID");
                                String firmaLokasyon = o.getString("FirmaLokasyon");
                                String kampanyaIcerik = o.getString("KampanyaIcerik");
                                String kampanyaSuresi = o.getString("KampanyaSuresi");
                                String tur = o.getString("Tur");
                                // Toast.makeText(list.this, lat1+" "+lng1+" "+mesafe, Toast.LENGTH_SHORT).show();

                                uzak = firmaLokasyon;
                                separated = uzak.split(",");
                                String lat = separated[0];
                                String lng = separated[1];
                                Double dlat = Double.parseDouble(lat1);
                                Double dlng = Double.parseDouble(lng1);
                                Double lat2 = Double.parseDouble(separated[0]);
                                Double lng2 = Double.parseDouble(separated[1]);
                                //Toast.makeText(list.this, dlat+"  "+dlng+"  ", Toast.LENGTH_SHORT).show();
                                double olanMesafe = distance(dlat, dlng, lat2, lng2, "M");
                                olanMesafe = olanMesafe * 1609.344;     // mile to meter
                                double istenenMesafe = Double.parseDouble(mesafe);

                                if (olanMesafe < istenenMesafe || istenenMesafe == 0){
                                    //    Toast.makeText(list.this, firmaID+"  "+olanMesafe, Toast.LENGTH_SHORT).show();
                                    olanMesafe=Math.ceil(olanMesafe);
                                    if (magaza.equalsIgnoreCase("Hepsi")) {

                                        if (kategori.equalsIgnoreCase(tur)) {
                                            list.add( firmaID );
                                        } else if (kategori.equalsIgnoreCase("Tüm Kategoriler")) {
                                            list.add( firmaID );
                                        } else if (kategori.equalsIgnoreCase(null)) {
                                            list.add( firmaID );
                                        }
                                        //   heroes.add(firmaAdi+" \n"+firmaID+" \nTür: "+tur+" \nLokasyon: "+firmaLokasyon+" \n"+kampanyaIcerik+" \n"+kampanyaSuresi+"\n\n");
                                    } else if (magaza.equalsIgnoreCase(firmaAdi)) {

                                        if (kategori.equalsIgnoreCase(tur)) {
                                            list.add( firmaID );
                                        } else if (kategori.equalsIgnoreCase("Tüm Kategoriler")) {
                                            list.add( firmaID );
                                        } else if (kategori.equalsIgnoreCase(null)) {
                                            list.add( firmaID );
                                           }
                                        //   heroes.add(firmaAdi+" \n"+firmaID+" \nTür: "+tur+" \nLokasyon: "+firmaLokasyon+" \n"+kampanyaIcerik+" \n"+kampanyaSuresi+"\n\n");
                                    }
                                }

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

             /*    try {
                            JSONObject jsonObject=new JSONObject(response);
                            JSONArray array=jsonObject.getJSONArray("firmalar");

                            for(int i=0; i<array.length(); i++){
                                JSONObject o=array.getJSONObject(i);
                                String id = o.getString("id");
                                String firmaAdi = o.getString("FirmaAdi");
                                String firmaID = o.getString("FirmaID");
                                String firmaLokasyon = o.getString("FirmaLokasyon");
                                String kampanyaIcerik = o.getString("KampanyaIcerik");
                                String kampanyaSuresi = o.getString("KampanyaSuresi");
                                String tur = o.getString("Tur");

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }*/
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String veri=list.get(position);
                Intent my=new Intent(list.this,MapsActivity2.class);
                my.putExtra("veri", veri);//açtığımız sayfaya haber id yi gönderme
                startActivityForResult(my,0);
            }
        });
    }
    private void getJSON(final String urlWebService) {

        class GetJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                jsonParse(s);
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        GetJSON getJSON = new GetJSON();
        getJSON.execute();
    }


    private void jsonParse(final String value){

        String url = "https://us-central1-savvy-raceway-239511.cloudfunctions.net/getItems";
        listView = findViewById(R.id.listView);
        final ArrayList<String>heroes=new ArrayList<>();

        StringRequest stringRequest=new StringRequest(Request.Method.GET,url,new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {

                    String kategori = getIntent().getExtras().getString("kategori");
                    String magaza = getIntent().getExtras().getString("magaza");
                    lat1 = getIntent().getExtras().getString("lat1");
                    lng1 = getIntent().getExtras().getString("lng1");
                    mesafe = getIntent().getExtras().getString("mesafe");

                    JSONArray array = new JSONArray(response);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject o = array.getJSONObject(i);

                        String id = o.getString("id");
                        String firmaAdi = o.getString("FirmaAdi");
                        String firmaID = o.getString("FirmaID");
                        String firmaLokasyon = o.getString("FirmaLokasyon");
                        String kampanyaIcerik = o.getString("KampanyaIcerik");
                        String kampanyaSuresi = o.getString("KampanyaSuresi");
                        String tur = o.getString("Tur");
                        // Toast.makeText(list.this, lat1+" "+lng1+" "+mesafe, Toast.LENGTH_SHORT).show();

                        uzak = firmaLokasyon;
                        separated = uzak.split(",");
                        String lat = separated[0];
                        String lng = separated[1];
                        Double dlat = Double.parseDouble(lat1);
                        Double dlng = Double.parseDouble(lng1);
                        Double lat2 = Double.parseDouble(separated[0]);
                        Double lng2 = Double.parseDouble(separated[1]);
                        //Toast.makeText(list.this, dlat+"  "+dlng+"  ", Toast.LENGTH_SHORT).show();
                        double olanMesafe = distance(dlat, dlng, lat2, lng2, "M");
                        olanMesafe = olanMesafe * 1609.344;     // mile to meter
                        double istenenMesafe = Double.parseDouble(mesafe);

                        if (olanMesafe < istenenMesafe || istenenMesafe == 0){
                          //    Toast.makeText(list.this, firmaID+"  "+olanMesafe, Toast.LENGTH_SHORT).show();
                             olanMesafe=Math.ceil(olanMesafe);
                            if (magaza.equalsIgnoreCase("Hepsi")) {

                                if (kategori.equalsIgnoreCase(tur)) {
                                    heroes.add(firmaAdi + " \n" + firmaID + " \nTür: " + tur + " \nLokasyon: " + firmaLokasyon + " \n" + kampanyaIcerik + " \n" + kampanyaSuresi +
                                            " gün\nMağazayla aranızdaki mesafe: "+olanMesafe+" Metre\n");
                                } else if (kategori.equalsIgnoreCase("Tüm Kategoriler")) {
                                    heroes.add(firmaAdi + " \n" + firmaID + " \nTür: " + tur + " \nLokasyon: " + firmaLokasyon + " \n" + kampanyaIcerik + " \n" + kampanyaSuresi +
                                            " gün\nMağazayla aranızdaki mesafe: "+olanMesafe+" Metre\n");
                                } else if (kategori.equalsIgnoreCase(null)) {
                                    heroes.add(firmaAdi + " \n" + firmaID + " \nTür: " + tur + " \nLokasyon: " + firmaLokasyon + " \n" + kampanyaIcerik + " \n" + kampanyaSuresi +
                                            " gün\nMağazayla aranızdaki mesafe: "+olanMesafe+" Metre\n");
                                }
                                //   heroes.add(firmaAdi+" \n"+firmaID+" \nTür: "+tur+" \nLokasyon: "+firmaLokasyon+" \n"+kampanyaIcerik+" \n"+kampanyaSuresi+"\n\n");
                            } else if (magaza.equalsIgnoreCase(firmaAdi)) {

                                if (kategori.equalsIgnoreCase(tur)) {
                                    heroes.add(firmaAdi + " \n" + firmaID + " \nTür: " + tur + " \nLokasyon: " + firmaLokasyon + " \n" + kampanyaIcerik + " \n" + kampanyaSuresi +
                                            " gün\nMağazayla aranızdaki mesafe: "+olanMesafe+" Metre\n");
                                } else if (kategori.equalsIgnoreCase("Tüm Kategoriler")) {
                                    heroes.add(firmaAdi + " \n" + firmaID + " \nTür: " + tur + " \nLokasyon: " + firmaLokasyon + " \n" + kampanyaIcerik + " \n" + kampanyaSuresi +
                                            " gün\nMağazayla aranızdaki mesafe: "+olanMesafe+" Metre\n");
                                } else if (kategori.equalsIgnoreCase(null)) {
                                    heroes.add(firmaAdi + " \n" + firmaID + " \nTür: " + tur + " \nLokasyon: " + firmaLokasyon + " \n" + kampanyaIcerik + " \n" + kampanyaSuresi +
                                            " gün\nMağazayla aranızdaki mesafe: "+olanMesafe+" Metre\n");
                                }
                                //   heroes.add(firmaAdi+" \n"+firmaID+" \nTür: "+tur+" \nLokasyon: "+firmaLokasyon+" \n"+kampanyaIcerik+" \n"+kampanyaSuresi+"\n\n");
                            }
                    }

                }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, heroes);
                listView.setAdapter(arrayAdapter);
if(heroes.size()==0){
    Toast.makeText(list.this, "Üzgünüz, kriterlerinize göre mağaza bulunamadı..", Toast.LENGTH_SHORT).show();
}
            //  Toast.makeText(list.this, lat1+" "+lng1+" "+mesafe, Toast.LENGTH_SHORT).show();

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                }
        );
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }


    private static double distance(double lat1, double lon1, double lat2, double lon2, String unit) {
        if ((lat1 == lat2) && (lon1 == lon2)) {
            return 0;
        }
        else {
            double theta = lon1 - lon2;
            double dist = Math.sin(Math.toRadians(lat1)) * Math.sin(Math.toRadians(lat2)) + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.cos(Math.toRadians(theta));
            dist = Math.acos(dist);
            dist = Math.toDegrees(dist);
            dist = dist * 60 * 1.1515;
            if (unit == "K") {  //kilometre
                dist = dist * 1.609344;
            } else if (unit == "N") {  //deniz mili
                dist = dist * 0.8684;
            }
            return (dist);
        }
    }

    }

