package com.example.asus.gps;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;


public class FirmaAdapter extends ArrayAdapter<Firma> {

    private final LayoutInflater inflater;
    private final Context context;
    private ViewHolder holder;
    private final ArrayList<Firma> firmalar;

    public FirmaAdapter(Context context , ArrayList<Firma> f) {
        super(context,0, f);
        this.context = context;
        this.firmalar = f;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return firmalar.size();
    }

    @Override
    public Firma getItem(int position) {
        return firmalar.get(position);
    }

    @Override
    public long getItemId(int position) {
        return firmalar.get(position).hashCode();
    }

    @Override
    public View getView(int position , View convertView , ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.firmaadapter, null);

            holder = new ViewHolder();
            holder.fAdi = (TextView) convertView.findViewById(R.id.textView10);
            holder.fLokasyon=(TextView) convertView.findViewById(R.id.textView12);
            holder.kİcerik = (TextView) convertView.findViewById(R.id.textView13);
            holder.kSüresi=(TextView) convertView.findViewById(R.id.textView14);
            holder.kategori=(TextView)convertView.findViewById( R.id.textView15);
            holder.id=(TextView)convertView.findViewById( R.id.textView11 );

            convertView.setTag(holder);

        }
        else{
            holder = (ViewHolder)convertView.getTag();
        }

        Firma fSatir = firmalar.get(position);
        if(fSatir != null){
            holder.fAdi.setText(fSatir.getFirmaAdi());
            holder.id.setText( fSatir.getFirmaID() );
            holder.fLokasyon.setText(fSatir.getFirmaLokasyon());
            holder.kİcerik.setText(fSatir.getKampanyaIcerik());
            holder.kSüresi.setText(fSatir.getKampanyaSuresi());
            holder.kategori.setText( fSatir.getTur() );


        }
        return convertView;

    }

    private static class ViewHolder {
        TextView fAdi;
        TextView fLokasyon;
        TextView kİcerik;
        TextView kSüresi;
        TextView kategori;
        TextView id;
    }


}



