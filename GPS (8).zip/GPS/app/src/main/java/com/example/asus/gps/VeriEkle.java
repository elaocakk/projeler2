package com.example.asus.gps;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class VeriEkle extends AppCompatActivity implements View.OnClickListener {

    private EditText firmaid;
    private EditText firmaad;
    private EditText firmalokasyon;
    private EditText icerik;
    private EditText sure;
    private EditText tur;
    private FirebaseAuth firebaseAuth;
    private Button ekle;
    private String ff,f2,f3,f4,f5,f6;
    private int f1;
    DatabaseReference database;
    DatabaseReference myRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.veriekle);
       database = FirebaseDatabase.getInstance().getReference();
        firebaseAuth=FirebaseAuth.getInstance();

        firmaid=(EditText)findViewById(R.id.firmaid);
        firmaad=(EditText)findViewById(R.id.firmaad);
        firmalokasyon=(EditText)findViewById(R.id.firmalokasyon);
        icerik=(EditText)findViewById(R.id.icerik);
        sure=(EditText)findViewById(R.id.sure);
        tur=(EditText)findViewById(R.id.tur);
        ekle=(Button)findViewById(R.id.button);
        ekle.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view==ekle){
            firmalar();
    }
    }


    public void firmalar(){
        String f=firmaid.getText().toString().trim();
        f1= Integer.parseInt(f)-1;
        ff=Integer.toString(f1);
        f2=firmaad.getText().toString().trim();
        f3=firmalokasyon.getText().toString().trim();
        f4=icerik.getText().toString().trim();
        f5=sure.getText().toString().trim();
        f6=tur.getText().toString().trim();
        Toast.makeText(this,"  "+f1+"  "+f2,Toast.LENGTH_LONG).show();
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference ref = database.getReference("firmalar");
        DatabaseReference usersRef = ref.child(ff);
        usersRef.child("FirmaAdi").setValue(f2);
        usersRef.child("FirmaID").setValue(f);
        usersRef.child("FirmaLokasyon").setValue(f3);
        usersRef.child("KampanyaIcerik").setValue(f4);
        usersRef.child("KampanyaSuresi").setValue(f5);
        usersRef.child("Tur").setValue(f6);

    }
}
