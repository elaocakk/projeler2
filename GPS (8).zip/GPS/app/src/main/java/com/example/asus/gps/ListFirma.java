package com.example.asus.gps;

import android.content.Intent;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


public class ListFirma extends AppCompatActivity {

    private static final String TAG = "ViewDatabase";

    private ListView listview;
    private EditText textMagaza;
    private EditText textUzaklık;
    private Button listele;
    private TextView textView;
    private TextView textView2;
    FirebaseDatabase database;
    DatabaseReference ref;
    final ArrayList<Firma> firmalar = new ArrayList<Firma>();
    FirmaAdapter adapter;
    Firma firma;
    String kategori="Tüm Kategoriler";
    String magaza="Hepsi";
    private String mesafe="0";
    private String latitude;
    private String longitude;
    private String[] türler = {"Tüm Kategoriler","Giyim","Elektronik","Kozmetik","Yiyecek"};
    private Spinner spinnerTürler;
    private ArrayAdapter<String> dataAdapterForTürler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listfirma);

        textMagaza=(EditText)findViewById(R.id.editText);
        textUzaklık=(EditText)findViewById(R.id.editText5);
        textView=(TextView)findViewById(R.id.textView);
        textView2=(TextView)findViewById(R.id.textView3);
        listele=(Button)findViewById(R.id.button9);
        listview = (ListView) findViewById(R.id.listview);
        spinnerTürler = (Spinner) findViewById(R.id.spinner);
        dataAdapterForTürler = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, türler);
        dataAdapterForTürler.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTürler.setAdapter(dataAdapterForTürler);
      //  kategori=textMagaza.getText().toString();
       // Toast.makeText( ListFirma.this,kategori,Toast.LENGTH_SHORT ).show();
        textView2.setTypeface(null, Typeface.ITALIC);
        firma=new Firma();
        database=FirebaseDatabase.getInstance();
        ref=database.getReference("firmalar");
        spinnerTürler.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (parent.getSelectedItem().toString().equals( türler[1] )) {
                    kategori = "Giyim";
                } else if (parent.getSelectedItem().toString().equals( türler[2] )) {
                    kategori = "Elektronik";
                } else if (parent.getSelectedItem().toString().equals( türler[3] )) {
                    kategori = "Kozmetik";
                } else if (parent.getSelectedItem().toString().equals( türler[4] )) {
                    kategori = "Yiyecek";
                } else if (parent.getSelectedItem().toString().equals( türler[0] )) {
                    kategori = "Tüm Kategoriler";
                }
                //Toast.makeText(MainActivity.this, "Haber Türü:" + habertürü, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                kategori = "Tüm Kategoriler";
            }
        });

        listele.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (textMagaza.getText().toString().trim().equals("")){
                    magaza="Hepsi";
                }
                else {
                    magaza=textMagaza.getText().toString();
                }
                if (textUzaklık.getText().toString().trim().equals("")){
                 mesafe="0";
                }
                else{
                    mesafe=textUzaklık.getText().toString().trim();
                   /* separated = uzak.split(" ");
                    lat = separated[0];
                    lng = separated[1];*/
                }
                latitude=getIntent().getExtras().getString("latitude");
                longitude=getIntent().getExtras().getString("longitude");
             //   Toast.makeText(ListFirma.this, mesafe+" "+latitude+" "+longitude, Toast.LENGTH_SHORT).show();
                Intent i = new Intent(ListFirma.this, list.class);
                i.putExtra("kategori",kategori);
                i.putExtra("magaza",magaza);
                i.putExtra("mesafe",mesafe);
                i.putExtra("lat1",latitude);
                i.putExtra("lng1",longitude);
                startActivity(i);
            }
        } );

    }

    public void listele(String k) {
        kategori=k;
Toast.makeText(ListFirma.this, " " + kategori, Toast.LENGTH_SHORT).show();
        ref.addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()) {
                    firma=ds.getValue(Firma.class);

                    if(firma!=null) {
                        //kategori=textKategori.getText().toString();
                        if (kategori.equalsIgnoreCase( firma.getTur().toString() )) {
                            firmalar.add( firma );
                        }
                        if (kategori.equalsIgnoreCase("Tüm Kategoriler")) {
                            firmalar.add( firma );
                        }

                        // } else if (kategori.equalsIgnoreCase( firma.getFirmaLokasyon().toString() )) {
                     //   firmalar.add( firma );
                        //}
                    }

                }

                adapter = new FirmaAdapter(ListFirma.this, firmalar);
                listview.setAdapter( adapter );
                //firma=null;
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText( ListFirma.this,"onCancelled!",Toast.LENGTH_SHORT ).show();
            }

        } );
    }

}
