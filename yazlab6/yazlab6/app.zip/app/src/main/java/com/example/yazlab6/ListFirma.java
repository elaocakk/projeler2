package com.example.yazlab6;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ListFirma extends AppCompatActivity {
    private static final String TAG = "ViewDatabase";

    private ListView listview;
    private EditText textKategori;
    private Button listele;
    FirebaseDatabase database;
    DatabaseReference ref;
    final ArrayList<Firma> firmalar = new ArrayList<Firma>();
    FirmaAdapter adapter;
    Firma firma;
    String kategori=null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listpage);

        textKategori=(EditText)findViewById(R.id.editText);
        listele=(Button)findViewById(R.id.button9);
        listview = (ListView) findViewById(R.id.listview);

        kategori=textKategori.getText().toString();
        Toast.makeText( ListFirma.this,kategori,Toast.LENGTH_SHORT ).show();

        firma=new Firma();
        database=FirebaseDatabase.getInstance();
        ref=database.getReference("firmalar");

        listele.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listele(kategori);
            }
        } );

    }

    public void listele(String k) {
        kategori=k;

        ref.addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds: dataSnapshot.getChildren()) {
                    firma=ds.getValue(Firma.class);

                    if(firma!=null) {
                        //if (kategori.equalsIgnoreCase( firma.getFirmaAdi().toString() )) {
                            firmalar.add( firma );
                       // } else if (kategori.equalsIgnoreCase( firma.getFirmaLokasyon().toString() )) {
                            firmalar.add( firma );
                        //}
                    }

                }

                adapter = new FirmaAdapter(ListFirma.this, firmalar);
                listview.setAdapter( adapter );
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText( ListFirma.this,"onCancelled!",Toast.LENGTH_SHORT ).show();
            }

        } );
    }

}