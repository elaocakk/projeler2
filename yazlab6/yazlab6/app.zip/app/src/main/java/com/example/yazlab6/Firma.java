package com.example.yazlab6;

public class Firma {
    String firmaAdi;
    String firmaLokasyon;
    String kampanyaİcerik;
    String kampanyaSüresi;
    String kategori;

    public Firma(String a, String l, String i, String s, String k){
        firmaAdi=a;
        firmaLokasyon=l;
        kampanyaİcerik=i;
        kampanyaSüresi=s;
        kategori=k;
    }

    public Firma() {

    }

    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getFirmaAdi() {
        return firmaAdi;
    }

    public void setFirmaAdi(String firmaAdi) {
        this.firmaAdi = firmaAdi;
    }

    public String getFirmaLokasyon() {
        return firmaLokasyon;
    }

    public void setFirmaLokasyon(String firmaLokasyon) {
        this.firmaLokasyon = firmaLokasyon;
    }

    public String getKampanyaİcerik() {
        return kampanyaİcerik;
    }

    public void setKampanyaİcerik(String kampanyaİcerik) {
        this.kampanyaİcerik = kampanyaİcerik;
    }

    public String getKampanyaSüresi() {
        return kampanyaSüresi;
    }

    public void setKampanyaSüresi(String kampanyaSüresi) {
        this.kampanyaSüresi = kampanyaSüresi;
    }
}
