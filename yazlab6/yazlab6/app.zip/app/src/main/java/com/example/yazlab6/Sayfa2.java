package com.example.yazlab6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Sayfa2 extends AppCompatActivity  {

    private FirebaseAuth firebaseAuth;

    private TextView textViewUserEmail;
    private Button buttonLogout;
    private Button buttonEkle;
    private Button buttonListele;
    private Button buttonKonum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logout);

        firebaseAuth = FirebaseAuth.getInstance();

        if(firebaseAuth.getCurrentUser() == null){
            //closing this activity
            finish();
            startActivity(new Intent(Sayfa2.this, MainActivity.class));
        }

        FirebaseUser user = firebaseAuth.getCurrentUser();

        textViewUserEmail = (TextView) findViewById(R.id.textViewUserEmail);
        buttonLogout = (Button) findViewById(R.id.buttonLogout);
        buttonEkle=(Button)findViewById( R.id.button6 );
        buttonListele=(Button)findViewById( R.id.button7 );
        buttonKonum=(Button)findViewById( R.id.button10 );

        //textViewUserEmail.setText("Welcome "+user.getEmail());

        buttonLogout.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.signOut();
                finish();

                startActivity(new Intent(Sayfa2.this, MainActivity.class));
            }
        } );

        buttonEkle.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Sayfa2.this, FirmaEkle.class));
            }
        } );

        buttonListele.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Sayfa2.this, ListFirma.class));
            }
        } );

        buttonKonum.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Sayfa2.this, GPSbulma.class));
            }
        } );

    }


}