package com.example.yazlab6;


import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class GPSbulma extends Activity {

    private TextView textViewUserEmail;
    private TextView konumText;
    private Button buttonGeri;
    private Button buttonGps;
    private Button buttonElle;

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.konumum );

        //konumText = (TextView)findViewById(R.id.textView4);
        //textViewUserEmail = (TextView) findViewById( R.id.textViewUserEmail );
        buttonGeri = (Button) findViewById( R.id.buttonLogout );
        buttonGps = (Button) findViewById( R.id.button11 );
        buttonElle = (Button) findViewById( R.id.button12 );

        buttonGeri.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(GPSbulma.this, GPSbulma.class));
            }
        } );

        buttonGps.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(GPSbulma.this, Profile.class));
            }
        } );

        buttonElle.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(GPSbulma.this, KonumEkle.class));
            }
        } );


    }






}
