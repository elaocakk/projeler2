package com.example.yazlab6;


import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;

public class Profile extends AppCompatActivity implements View.OnClickListener,ConnectionCallbacks, OnConnectionFailedListener{

    private FirebaseAuth firebaseAuth;
    private TextView textViewUserEmail;
    private Button buttonLogout;
    private Button konumBul;

    Geocoder geocoder;
    List<Address> addresses;

    public static final int RequestPermissionCode = 1;
    private GoogleApiClient googleApiClient;
    private TextView longitudeText;
    private TextView latitudeText;
    private Location lastLocation;
    private FusedLocationProviderClient fusedLocationProviderClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);

        buttonLogout=(Button) findViewById(R.id.buttonLogout);
        buttonLogout.setOnClickListener(this);
        konumBul=(Button) findViewById(R.id.konumBul);
        konumBul.setOnClickListener(this);

        //  longitudeText = (TextView) findViewById(R.id.longitude);
        latitudeText = (TextView) findViewById(R.id.latitude);
        geocoder=new Geocoder(this, Locale.getDefault());

        googleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        firebaseAuth=FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser()==null){
            finish();
            startActivity(new Intent(this,MainActivity.class));
        }
        FirebaseUser user =firebaseAuth.getCurrentUser();

        textViewUserEmail=(TextView)findViewById(R.id.textViewUserEmail);
        textViewUserEmail.setText("Hoşgeldiniz "+user.getEmail()+" !");

    }

    @Override
    public void onClick(View view) {
        if (view==buttonLogout){
            firebaseAuth.signOut();
            startActivity(new Intent(this,MainActivity.class)); finish();
        }

        if (view==konumBul){
            finish();
            startActivity(new Intent(this,MapsActivity.class));
        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        googleApiClient.connect();
    }

    @Override
    protected void onStop() {
        if (googleApiClient.isConnected()) {
            googleApiClient.disconnect();
        }
        super.onStop();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermission();
        } else {
            fusedLocationProviderClient.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            // Got last known location. In some rare situations this can be null.
                            if (location != null) {
                                // Logic to handle location object
                                try{
                                    addresses=geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
                                    String address=addresses.get(0).getAddressLine(0);
                                    String area=addresses.get(0).getLocality();
                                    String city=addresses.get(0).getAdminArea();
                                    String country=addresses.get(0).getCountryName();
                                    String postalcode=addresses.get(0).getPostalCode();
                                    String fullAddress="Konumunuz: "+address/*+", "+area+", "+city+", "+country+", "+postalcode*/;
                                    latitudeText.setText(fullAddress);

                                }
                                catch (IOException e) {
                                    e.printStackTrace();
                                }
                                //latitudeText.setText(String.valueOf(location.getLatitude()));
                                //longitudeText.setText(String.valueOf(location.getLongitude()));
                            }
                        }
                    });
        }
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(Profile.this, new String[]{ACCESS_FINE_LOCATION}, RequestPermissionCode);
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        //   Log.e("Profile", "Connection failed: " + connectionResult.getErrorCode());
        Toast.makeText(this,"Connection Failed",Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConnectionSuspended(int i) {
        //  Log.e("Profile", "Connection suspendedd");
        Toast.makeText(this,"Connection Suspended",Toast.LENGTH_LONG).show();
    }


}
