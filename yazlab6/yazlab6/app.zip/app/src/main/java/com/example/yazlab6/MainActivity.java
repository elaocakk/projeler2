package com.example.yazlab6;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends Activity {

    Button button1;
    Button button2;
    Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button1=(Button)findViewById( R.id.button2 );
        button2=(Button)findViewById( R.id.button3 );
        button3=(Button)findViewById( R.id.button4 );

        button1.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"Kullanıcı Giriş",Toast.LENGTH_SHORT).show();

                Intent intent=new Intent(MainActivity.this,KulGiriş.class);
                startActivity( intent );
            }
        } );

        button2.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"Kullanıcı Sifre Degistirme",Toast.LENGTH_SHORT).show();

                Intent intent=new Intent(MainActivity.this,SifreDegistir.class);
                startActivity( intent );
            }
        } );

        button3.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"Kullanıcı Kayit",Toast.LENGTH_SHORT).show();

                Intent intent=new Intent(MainActivity.this,KayitOl.class);
                startActivity( intent );
            }
        } );

    }
}


