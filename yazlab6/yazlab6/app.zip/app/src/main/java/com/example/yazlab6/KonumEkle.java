package com.example.yazlab6;

public class KonumEkle {
}
